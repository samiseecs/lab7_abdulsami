package main

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

func recursiveFileSearch() {
	var directory, filename string
	fmt.Print("Enter directory path: ")
	fmt.Scanln(&directory)
	fmt.Print("Enter file name to search: ")
	fmt.Scanln(&filename)

	found := false
	err := searchFile(directory, filename, &found)
	if err != nil {
		fmt.Printf("Error: %v\n", err)
		return
	}

	if !found {
		fmt.Println("File not found")
	}
}

func searchFile(dir, filename string, found *bool) error {
	files, err := os.ReadDir(dir)
	if err != nil {
		return fmt.Errorf("failed to open directory: %v", err)
	}

	for _, file := range files {
		fullPath := filepath.Join(dir, file.Name())
		if file.IsDir() {
			if err := searchFile(fullPath, filename, found); err != nil {
				return err
			}
		} else if strings.EqualFold(file.Name(), filename) {
			fmt.Printf("File found: %s\n", fullPath)
			*found = true
			return nil
		}
	}
	return nil
}
