package main

import (
	"os"
	"path/filepath"
	"testing"
)

func TestRecursiveFileSearch(t *testing.T) {
	tempDir := t.TempDir()
	nestedDir := filepath.Join(tempDir, "nested")
	err := os.Mkdir(nestedDir, 0755)
	if err != nil {
		t.Fatalf("Failed to create nested directory: %v", err)
	}

	targetFile := filepath.Join(nestedDir, "testfile.txt")
	err = os.WriteFile(targetFile, []byte("test content"), 0644)
	if err != nil {
		t.Fatalf("Failed to create test file: %v", err)
	}

	found := false
	err = searchFile(tempDir, "testfile.txt", &found)

	if err != nil {
		t.Errorf("Error during file search: %v", err)
	}
	if !found {
		t.Errorf("Expected file to be found, but it was not.")
	}

	found = false
	err = searchFile(tempDir, "nonexistent.txt", &found)
	if found {
		t.Errorf("Expected file to not be found, but it was.")
	}
}

func TestGenerateUniquePermutations(t *testing.T) {
	input := "aab"
	expected := map[string]bool{
		"aab": true,
		"aba": true,
		"baa": true,
	}

	result := generateUniquePermutations(input)

	resultMap := make(map[string]bool)
	for _, perm := range result {
		resultMap[perm] = true
	}

	for perm := range expected {
		if !resultMap[perm] {
			t.Errorf("Expected permutation %s not found in results", perm)
		}
	}
}

func TestGeneratePermutationsIteratively(t *testing.T) {
	input := "abc"
	expected := map[string]bool{
		"abc": true,
		"acb": true,
		"bac": true,
		"bca": true,
		"cab": true,
		"cba": true,
	}

	result := generatePermutationsIteratively(input)

	resultMap := make(map[string]bool)
	for _, perm := range result {
		resultMap[perm] = true
	}

	for perm := range expected {
		if !resultMap[perm] {
			t.Errorf("Expected permutation %s not found in results", perm)
		}
	}
}
