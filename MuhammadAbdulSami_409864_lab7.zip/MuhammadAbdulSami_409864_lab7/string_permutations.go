package main

import (
	"fmt"
)

func recursiveStringPermutations() {
	var input string
	fmt.Print("Enter a string: ")
	fmt.Scanln(&input)

	fmt.Println("Permutations (Recursive, Unique):")
	uniquePermutations := generateUniquePermutations(input)
	for _, perm := range uniquePermutations {
		fmt.Println(perm)
	}

	fmt.Println("\nPermutations (Iterative):")
	iterativePermutations := generatePermutationsIteratively(input)
	for _, perm := range iterativePermutations {
		fmt.Println(perm)
	}
}

func generateUniquePermutations(s string) []string {
	result := map[string]bool{}
	permuteUnique([]rune(s), 0, &result)

	var uniqueResults []string
	for perm := range result {
		uniqueResults = append(uniqueResults, perm)
	}
	return uniqueResults
}

func permuteUnique(runes []rune, start int, result *map[string]bool) {
	if start == len(runes)-1 {
		(*result)[string(runes)] = true
		return
	}

	for i := start; i < len(runes); i++ {
		runes[start], runes[i] = runes[i], runes[start]
		permuteUnique(runes, start+1, result)
		runes[start], runes[i] = runes[i], runes[start]
	}
}

func generatePermutationsIteratively(s string) []string {
	var results []string
	results = append(results, string(s[0]))

	for i := 1; i < len(s); i++ {
		var newResults []string
		for _, str := range results {
			for j := 0; j <= len(str); j++ {
				newStr := str[:j] + string(s[i]) + str[j:]
				newResults = append(newResults, newStr)
			}
		}
		results = newResults
	}
	return results
}
