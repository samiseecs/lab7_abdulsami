package main

import (
	"fmt"
)

func main() {
	fmt.Println("Select Task:")
	fmt.Println("1. Recursive File Search")
	fmt.Println("2. Recursive String Permutations")
	var choice int
	fmt.Scanln(&choice)

	switch choice {
	case 1:
		recursiveFileSearch()
	case 2:
		recursiveStringPermutations()
	default:
		fmt.Println("Invalid choice")
	}
}
